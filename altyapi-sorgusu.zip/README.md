# Türkiye İnternet Altyapı Sorgusu

Bu uygulama, Türkiye’de internet altyapısı (Fiber / VDSL / ADSL) uygunluğunu adres bazlı olarak sorgulamak için hazırlanmıştır.
Streamlit Cloud üzerinde çalıştırılabilir.

## Çalıştırma
- Streamlit Cloud'a yükleyin.
- Tarayıcı üzerinden adres bilgilerinizi girerek sorgu yapabilirsiniz.
